I will provide you with a screenshot each time , its a german site Weinberger Aesthetics
create content from screenshot but for comments, classes etc use english
for html use pug, and for css use scss. 
dont provide html body head tags etc. 
for section title, use section-header, .section-header_title classes. 